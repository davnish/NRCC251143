# Structure
.
├── cloudSnip
│   ├── clac_statistics.py          # mean and std calc from dataset
│   ├── config.yml                  # parameters
│   ├── data_vis.ipynb              # Data Visualization
│   ├── dataset.py                  # Dataset Preparation Code
│   ├── inference.py                # inference pipeline
│   ├── loss.py                     # custom loss
│   ├── main.py                     # train val loop
│   ├── model.py                    # model logic
│   ├── processing
│   │   ├── liss4_processing.ipynb  # TOA processing code
│   │   ├── main.py
│   │   ├── pyproject.toml
│   │   ├── README.md
│   │   └── uv.lock
│   └── transforms.py               # transforms for the dataset
├── pyproject.toml
├── README.md
├── statistics.txt
└── uv.lock